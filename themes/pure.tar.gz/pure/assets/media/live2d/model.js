var models = [
  {
    name: 'models',
    models: [
      {
        name: 'model0',
        link: 'live2d/nepnep/index.json'
      }
    ]
  }
];
