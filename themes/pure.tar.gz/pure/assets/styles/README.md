styles: 样式文件夹，必须

main.less: 主样式文件，必须
